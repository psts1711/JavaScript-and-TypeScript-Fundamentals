let x= '9304682947'
let y = x.slice(0,5)
console.log(y);


let a = 9771805104
let b = String(a).slice(0,5)
console.log(b);

var code = 130031;
var last = code.toString().slice(-2);