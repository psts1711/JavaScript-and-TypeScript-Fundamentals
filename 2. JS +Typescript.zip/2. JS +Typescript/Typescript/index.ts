// Class Topic: Typing in Typescript

const myVariable : string[] = ['', ''];

// let myVar = ''
// myVar = 9

// let myVal : any = 'Hello'

// let myVar = [{}];
// myVar = [{}, {}];

function multiply(numA:number, numB:number): number{
    return numA * numB
}

const result = multiply(4, 4)
console.log(result)