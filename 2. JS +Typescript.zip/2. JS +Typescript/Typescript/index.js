"use strict";
// Class Topic: Typing in Typescript
const myVariable = ['', ''];
// let myVar = ''
// myVar = 9
// let myVal : any = 'Hello'
// let myVar = [{}];
// myVar = [{}, {}];
function multiply(numA, numB) {
    return numA * numB;
}
const result = multiply(4, 4);
console.log(result);
