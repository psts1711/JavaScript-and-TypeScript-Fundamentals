// CLASS TOPICS: ternary_operator is alternate of if-else
// it is shorthand if else for single / one true statement

isBreadAvailable = true;

isBreadAvailable ? console.log('I will make sandwitch today') : console.log('eat eggs today')

// ! => mean not 
!isBreadAvailable ? console.log('I will make sandwitch today') : console.log('eat eggs today')
