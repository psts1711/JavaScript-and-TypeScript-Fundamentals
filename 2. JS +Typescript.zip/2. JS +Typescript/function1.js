// CLASS TOPICS: Basic of Function / Method

function square(number)
{
    console.log(number * number)
}
square(5);
square(2);
square(3);


function multiplu(numA, numB)
{
    console.log(numA * numB)
}
multiplu(5, 25);

function multiply(numX)
{
    return numX * numX;
}
result = multiply(7);
console.log(result);