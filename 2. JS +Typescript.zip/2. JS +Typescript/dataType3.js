// CLASS TOPICS: OBJECT DATA TYPE
// id, name, age, email is key_value

myValue = {
	id:1,
	name: "Prafful",
	age: "25",
	email: "prafful1711@gmail.com"
}
myKeyValue = myValue["name"] //method 1
myKeyValue2 = myValue.email    //method 2

console.log(myKeyValue)
console.log(myKeyValue2)			

