// CLASS TOPICS: Break and Countinue Statement
// in karne par index value return karega 
// of karne par value return karega


a = [1,2,3,4,5]

for(item of a)
{
    console.log(item)
    if(item>2)
    {
        break;
    }
    console.log(item*item)
}
