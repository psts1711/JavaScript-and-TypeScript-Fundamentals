export function callMeACat()
{
    console.log('I am a Cat')
}