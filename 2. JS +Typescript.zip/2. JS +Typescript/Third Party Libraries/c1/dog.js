export function callMeADog()
{
    console.log('Hello, I am a new dog');
}

function callDefault() {
    console.log('I am a default export function');

}

export default callDefault;