// CLASS TOPICS: STRING DATA TYPE

// "H", "E", "L", "L", "O"

myValue = "hello"
console.log(myValue)
myValue = 1
console.log(myValue, "Called 2")
myValue = [1,2,3]
console.log(myValue, "Called 3")

/*How string is save in myValue*/
// ["h", "e", "l", "l", "o"]
myValue = "hello"
console.log(myValue[1])

/* Basic 2 */
myValue = "Hello, My name is:\n Prafful"
console.log(myValue)
