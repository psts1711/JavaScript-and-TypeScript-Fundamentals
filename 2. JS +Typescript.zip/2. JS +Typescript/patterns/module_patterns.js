"use strict";
// Class Topic: Module Pattern
Object.defineProperty(exports, "__esModule", { value: true });
var module_car_js_1 = require("./module_car.js");
var myCar = new module_car_js_1.Car('innove', '2020', 780000);
myCar.tellAboutCar();
