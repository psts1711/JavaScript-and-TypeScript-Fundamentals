// Class Topic: Module Pattern

import {Car} from './module_car.js'

const myCar = new Car('innove', '2020', 780000)
myCar.tellAboutCar();