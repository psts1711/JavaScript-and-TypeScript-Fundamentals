// SYMBOLS

// library code

// let id = Symbol('id');

// let user = {
// [id]: 'myUserId',
// name :"shagun",
// age:22
// };

// my code where i am trying to use library
// const mySymbols = Object.getOwnPropertySymbols(user);
// user[id] = "newId";
// console.log(user);

// GLOBAL SYMBOL

// let id = Symbol.for('id');

// let id2 = Symbol.for('id');

// console.log(id == id2);

// console.log(Symbol.keyFor(id));

// console.log(Symbol.keyFor(id2));