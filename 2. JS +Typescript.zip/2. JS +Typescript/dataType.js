
// integers in js -> numbers


// decimal -> float

// String

/*-------------------------*/
// array is define by symbol []
myList = [10, 250, 35, 25]
console.log(myList) // print all array list

// how data store in a array
/* [0index->1, 
	1index->250, 
	2index->35, 
	3index-> 25 ] */

myValue=myList[3];	//print specific index
console.log(myValue) 

